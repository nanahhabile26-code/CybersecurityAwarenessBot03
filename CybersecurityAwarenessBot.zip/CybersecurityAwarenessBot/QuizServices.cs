﻿
using System.Collections.Generic;
using CybersecurityAwarenessBot.Models;

namespace CybersecurityAwarenessBot.Services
{
    public class QuizService
    {
        private readonly List<QuizQuestion> _questions = new();

        private int _currentIndex;
        private int _score;

        public int TotalQuestions => _questions.Count;

        public int CurrentNumber => _currentIndex + 1;

        public int Score => _score;

        public bool IsLastQuestion =>
            _currentIndex == _questions.Count - 1;

        public QuizQuestion Current =>
            _questions[_currentIndex];

        public QuizService()
        {
            LoadQuestions();
        }

        private void LoadQuestions()
        {
            _questions.Clear();

            _questions.Add(new QuizQuestion
            {
                Text = "What is phishing?",
                Options = new List<string>
                {
                    "A type of computer hardware",
                    "A fraudulent attempt to steal information",
                    "A computer programming language",
                    "A method of backing up files"
                },
                CorrectIndex = 1,
                Explanation = "Phishing uses fake messages or websites to steal sensitive information."
            });

            _questions.Add(new QuizQuestion
            {
                Text = "What makes a password strong?",
                Options = new List<string>
                {
                    "Using your name",
                    "Using 123456",
                    "Using a long, unique combination",
                    "Using your birthday"
                },
                CorrectIndex = 2,
                Explanation = "A long and unique password is harder to guess."
            });

            _questions.Add(new QuizQuestion
            {
                Text = "What should you do with a suspicious email?",
                Options = new List<string>
                {
                    "Click every link",
                    "Forward it to everyone",
                    "Ignore security warnings",
                    "Avoid links and report it"
                },
                CorrectIndex = 3,
                Explanation = "Suspicious emails should be reported and their links avoided."
            });

            _questions.Add(new QuizQuestion
            {
                Text = "What is two-factor authentication?",
                Options = new List<string>
                {
                    "Using two usernames",
                    "An additional identity verification step",
                    "Sharing your password",
                    "Disabling account security"
                },
                CorrectIndex = 1,
                Explanation = "Two-factor authentication adds another layer of account protection."
            });

            _questions.Add(new QuizQuestion
            {
                Text = "Why should software be updated?",
                Options = new List<string>
                {
                    "To fix security vulnerabilities",
                    "To remove all passwords",
                    "To share personal information",
                    "To disable antivirus software"
                },
                CorrectIndex = 0,
                Explanation = "Updates often fix vulnerabilities and improve security."
            });
        }

        public void Start()
        {
            _currentIndex = 0;
            _score = 0;
        }

        public bool SubmitAnswer(int selectedIndex)
        {
            if (selectedIndex < 0 ||
                selectedIndex >= Current.Options.Count)
            {
                return false;
            }

            bool correct = selectedIndex == Current.CorrectIndex;

            if (correct)
            {
                _score++;
            }

            return correct;
        }

        public void MoveNext()
        {
            if (!IsLastQuestion)
            {
                _currentIndex++;
            }
        }

        public string GetFinalFeedback()
        {
            if (_score == TotalQuestions)
                return "Excellent! You are a cybersecurity champion!";

            if (_score >= 3)
                return "Well done! You have a good understanding of cybersecurity.";

            return "Keep practising! Review your cybersecurity awareness notes.";
        }
    }
}
