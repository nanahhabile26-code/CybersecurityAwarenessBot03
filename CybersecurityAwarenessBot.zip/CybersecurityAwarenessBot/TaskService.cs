﻿
using System;
using System.Collections.Generic;
using CybersecurityAwarenessBot.Models;
using MySqlCmd = MySqlConnector.MySqlCommand;

namespace CybersecurityAwarenessBot.Services
{
    public class TaskService
    {
        private readonly DatabaseService _db;

        public TaskService(DatabaseService db)
        {
            _db = db;
        }

        public int AddTask(
            string title,
            string description,
            DateTime? reminder)
        {
            const string sql = @"
                INSERT INTO CyberTasks
                (Title, Description, ReminderDate)
                VALUES (@title, @desc, @rem)";

            using (var conn = _db.GetConnection())
            {
                conn.Open();

                using (var cmd = new MySqlCmd(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@desc", description ?? "");
                    cmd.Parameters.AddWithValue(
                        "@rem",
                        reminder.HasValue
                            ? (object)reminder.Value
                            : DBNull.Value);

                    cmd.ExecuteNonQuery();

                    return (int)cmd.LastInsertedId;
                }
            }
        }

        public List<CyberTask> GetAllTasks()
        {
            return ReadTasks(
                "SELECT * FROM CyberTasks ORDER BY IsCompleted ASC, CreatedAt DESC",
                null);
        }

        public List<CyberTask> GetDueReminders()
        {
            return ReadTasks(
                @"SELECT * FROM CyberTasks
                  WHERE IsCompleted = 0
                  AND ReminderDate IS NOT NULL
                  AND ReminderDate <= @now",
                DateTime.Now);
        }

        public void SetReminder(int taskId, DateTime reminder)
        {
            Execute(
                "UPDATE CyberTasks SET ReminderDate = @value WHERE TaskId = @id",
                taskId,
                reminder);
        }

        public void MarkCompleted(int taskId)
        {
            Execute(
                "UPDATE CyberTasks SET IsCompleted = 1 WHERE TaskId = @id",
                taskId,
                null);
        }

        public void DeleteTask(int taskId)
        {
            Execute(
                "DELETE FROM CyberTasks WHERE TaskId = @id",
                taskId,
                null);
        }

        private void Execute(
            string sql,
            int taskId,
            DateTime? value)
        {
            using (var conn = _db.GetConnection())
            {
                conn.Open();

                using (var cmd = new MySqlCmd(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", taskId);

                    if (value.HasValue)
                    {
                        cmd.Parameters.AddWithValue(
                            "@value", value.Value);
                    }

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private List<CyberTask> ReadTasks(
            string sql,
            DateTime? nowParam)
        {
            List<CyberTask> list = new();

            using (var conn = _db.GetConnection())
            {
                conn.Open();

                using (var cmd = new MySqlCmd(sql, conn))
                {
                    if (nowParam.HasValue)
                    {
                        cmd.Parameters.AddWithValue(
                            "@now", nowParam.Value);
                    }

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new CyberTask
                            {
                                TaskId = reader.GetInt32(
                                    reader.GetOrdinal("TaskId")),

                                Title = reader.GetString(
                                    reader.GetOrdinal("Title")),

                                Description = reader.IsDBNull(
                                    reader.GetOrdinal("Description"))
                                    ? ""
                                    : reader.GetString(
                                        reader.GetOrdinal("Description")),

                                ReminderDate = reader.IsDBNull(
                                    reader.GetOrdinal("ReminderDate"))
                                    ? null
                                    : reader.GetDateTime(
                                        reader.GetOrdinal("ReminderDate")),

                                IsCompleted = reader.GetBoolean(
                                    reader.GetOrdinal("IsCompleted")),

                                CreatedAt = reader.GetDateTime(
                                    reader.GetOrdinal("CreatedAt"))
                            });
                        }
                    }
                }
            }

            return list;
        }
    }
}
