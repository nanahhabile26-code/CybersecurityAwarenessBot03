﻿
using MySqlConn = MySqlConnector.MySqlConnection;
using MySqlCmd = MySqlConnector.MySqlCommand;

namespace CybersecurityAwarenessBot.Services
{
    public class DatabaseServices
    {
        // Replace YOUR_PASSWORD with your actual MySQL password.
        private const string ServerConnectionString =
            "Server=localhost;User ID=root;Password=YOUR_PASSWORD;";

        private const string DatabaseConnectionString =
            "Server=localhost;Database=cybersecuritybot;User ID=root;Password=YOUR_PASSWORD;";

        public MySqlConn GetConnection()
        {
            return new MySqlConn(DatabaseConnectionString);
        }

        public void CreateDatabaseAndTable()
        {
            using (var connection = new MySqlConn(ServerConnectionString))
            {
                connection.Open();

                using (var command = new MySqlCmd(
                    "CREATE DATABASE IF NOT EXISTS cybersecuritybot",
                    connection))
                {
                    command.ExecuteNonQuery();
                }
            }

            using (var connection = GetConnection())
            {
                connection.Open();

                const string tableQuery = @"
                    CREATE TABLE IF NOT EXISTS CyberTasks
                    (
                        TaskId INT AUTO_INCREMENT PRIMARY KEY,
                        Title VARCHAR(200) NOT NULL,
                        Description TEXT,
                        ReminderDate DATETIME NULL,
                        IsCompleted BOOLEAN DEFAULT FALSE,
                        CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
                    )";

                using (var command =
                    new MySqlCmd(tableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
