
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

private void TopicButton_Click(object sender, RoutedEventArgs e)
{
    if (sender is Button button)
    {
        string topic = button.Tag?.ToString()
                       ?? button.Content?.ToString()
                       ?? "General Cybersecurity";

        MessageBox.Show(
            "Selected topic: " + topic,
            "Cybersecurity Awareness",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }
}

private void InputBox_KeyDown(
    object sender,
    KeyEventArgs e)
{
    if (e.Key == Key.Enter)
    {
        SendButton_Click(sender, e);
        e.Handled = true;
    }
}

private void SendButton_Click(
    object sender,
    RoutedEventArgs e)
{
    // Connect this event to your existing Part 2
    // chatbot message-processing method.
}
