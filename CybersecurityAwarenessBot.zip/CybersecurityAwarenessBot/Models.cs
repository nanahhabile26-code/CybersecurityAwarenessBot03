﻿
using System;

namespace CybersecurityAwarenessBot.Models
{
    public class CyberTask
    {
        public int TaskId { get; set; }

        public string Title { get; set; } = "";

        public string Description { get; set; } = "";

        public DateTime? ReminderDate { get; set; }

        public bool IsCompleted { get; set; }

        public DateTime CreatedAt { get; set; }

        public override string ToString()
        {
            string status = IsCompleted ? "Completed" : "Pending";

            string reminder = ReminderDate.HasValue
                ? ReminderDate.Value.ToString("dd/MM/yyyy HH:mm")
                : "No reminder";

            return $"{Title} | {status} | Reminder: {reminder}";
        }
    }
}
